import React from 'react';

const TestProvider = ({ children }: React.PropsWithChildren<{}>) => {
  return <>{children}</>;
};

export default TestProvider;
