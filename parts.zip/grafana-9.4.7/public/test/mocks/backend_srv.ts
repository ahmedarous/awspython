export class BackendSrvMock {
  search: any;

  constructor() {}
}
