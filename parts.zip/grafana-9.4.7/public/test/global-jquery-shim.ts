import $ from 'jquery';

const global = window as any;
global.$ = global.jQuery = $;
